"""initial schema

Revision ID: 0001
Revises:
Create Date: 2026-01-01 00:00:00

"""
from alembic import op
import sqlalchemy as sa

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

user_role_enum = sa.Enum("analyst", "admin", name="userrole")
severity_enum = sa.Enum("low", "medium", "high", "critical", name="severitylevel")
detection_status_enum = sa.Enum("new", "reviewed", "confirmed", "false_positive", name="detectionstatus")
alert_status_enum = sa.Enum("open", "acknowledged", "resolved", "dismissed", name="alertstatus")
incident_status_enum = sa.Enum(
    "open", "investigating", "contained", "resolved", "closed", name="incidentstatus"
)
model_status_enum = sa.Enum("active", "inactive", "training", "deprecated", name="modelstatus")


def upgrade() -> None:
    bind = op.get_bind()
    user_role_enum.create(bind, checkfirst=True)
    severity_enum.create(bind, checkfirst=True)
    detection_status_enum.create(bind, checkfirst=True)
    alert_status_enum.create(bind, checkfirst=True)
    incident_status_enum.create(bind, checkfirst=True)
    model_status_enum.create(bind, checkfirst=True)

    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(120), nullable=False),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("role", user_role_enum, nullable=False, server_default="analyst"),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    op.create_table(
        "mitre_techniques",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("technique_id", sa.String(20), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("tactic", sa.String(120), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_mitre_techniques_technique_id", "mitre_techniques", ["technique_id"], unique=True)
    op.create_index("ix_mitre_techniques_tactic", "mitre_techniques", ["tactic"])

    op.create_table(
        "threats",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("category", sa.String(100), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("severity", sa.String(20), nullable=False, server_default="medium"),
        sa.Column("mitigation", sa.Text(), nullable=True),
    )
    op.create_index("ix_threats_name", "threats", ["name"])
    op.create_index("ix_threats_category", "threats", ["category"])

    op.create_table(
        "models",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("algorithm", sa.String(80), nullable=False),
        sa.Column("version", sa.String(30), nullable=False, server_default="1.0.0"),
        sa.Column("status", model_status_enum, nullable=False, server_default="inactive"),
        sa.Column("model_path", sa.String(500), nullable=False),
        sa.Column("accuracy", sa.Float(), nullable=True),
        sa.Column("precision", sa.Float(), nullable=True),
        sa.Column("recall", sa.Float(), nullable=True),
        sa.Column("f1_score", sa.Float(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_models_name", "models", ["name"])
    op.create_index("ix_models_status", "models", ["status"])

    op.create_table(
        "detections",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("timestamp", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("source_ip", sa.String(64), nullable=True),
        sa.Column("source_port", sa.Integer(), nullable=True),
        sa.Column("destination_ip", sa.String(64), nullable=True),
        sa.Column("destination_port", sa.Integer(), nullable=True),
        sa.Column("protocol", sa.String(20), nullable=True),
        sa.Column("prediction", sa.String(20), nullable=False),
        sa.Column("attack_type", sa.String(100), nullable=False),
        sa.Column("confidence", sa.Float(), nullable=False),
        sa.Column("severity", severity_enum, nullable=False),
        sa.Column("risk_score", sa.Float(), nullable=False),
        sa.Column("explanation", sa.Text(), nullable=True),
        sa.Column("mitre_technique_id", sa.Integer(), sa.ForeignKey("mitre_techniques.id"), nullable=True),
        sa.Column("model_id", sa.Integer(), sa.ForeignKey("models.id"), nullable=True),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("status", detection_status_enum, nullable=False, server_default="new"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_detections_timestamp", "detections", ["timestamp"])
    op.create_index("ix_detections_source_ip", "detections", ["source_ip"])
    op.create_index("ix_detections_destination_ip", "detections", ["destination_ip"])
    op.create_index("ix_detections_attack_type", "detections", ["attack_type"])
    op.create_index("ix_detections_severity", "detections", ["severity"])
    op.create_index("ix_detections_risk_score", "detections", ["risk_score"])
    op.create_index("ix_detections_status", "detections", ["status"])

    op.create_table(
        "alerts",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("detection_id", sa.Integer(), sa.ForeignKey("detections.id"), nullable=False, unique=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("severity", severity_enum, nullable=False),
        sa.Column("risk_score", sa.Float(), nullable=False),
        sa.Column("status", alert_status_enum, nullable=False, server_default="open"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolved_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
    )
    op.create_index("ix_alerts_severity", "alerts", ["severity"])
    op.create_index("ix_alerts_status", "alerts", ["status"])

    op.create_table(
        "incidents",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("severity", severity_enum, nullable=False),
        sa.Column("status", incident_status_enum, nullable=False, server_default="open"),
        sa.Column("assigned_to", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_incidents_severity", "incidents", ["severity"])
    op.create_index("ix_incidents_status", "incidents", ["status"])

    op.create_table(
        "incident_alerts",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("incident_id", sa.Integer(), sa.ForeignKey("incidents.id"), nullable=False),
        sa.Column("alert_id", sa.Integer(), sa.ForeignKey("alerts.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("ix_incident_alerts_incident_id", "incident_alerts", ["incident_id"])
    op.create_index("ix_incident_alerts_alert_id", "incident_alerts", ["alert_id"])

    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("action", sa.String(120), nullable=False),
        sa.Column("resource", sa.String(80), nullable=False),
        sa.Column("resource_id", sa.String(50), nullable=True),
        sa.Column("timestamp", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("log_metadata", sa.JSON(), nullable=True),
    )
    op.create_index("ix_audit_logs_user_id", "audit_logs", ["user_id"])
    op.create_index("ix_audit_logs_action", "audit_logs", ["action"])
    op.create_index("ix_audit_logs_timestamp", "audit_logs", ["timestamp"])


def downgrade() -> None:
    op.drop_table("audit_logs")
    op.drop_table("incident_alerts")
    op.drop_table("incidents")
    op.drop_table("alerts")
    op.drop_table("detections")
    op.drop_table("models")
    op.drop_table("threats")
    op.drop_table("mitre_techniques")
    op.drop_table("users")

    bind = op.get_bind()
    model_status_enum.drop(bind, checkfirst=True)
    incident_status_enum.drop(bind, checkfirst=True)
    alert_status_enum.drop(bind, checkfirst=True)
    detection_status_enum.drop(bind, checkfirst=True)
    severity_enum.drop(bind, checkfirst=True)
    user_role_enum.drop(bind, checkfirst=True)
