import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Loader2, ScanSearch } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SeverityBadge } from "@/components/common/SeverityBadge";
import { ConfidenceMeter, RiskIndicator } from "@/components/common/RiskIndicator";
import { ErrorState } from "@/components/common/States";
import { detectionService } from "@/lib/api/services";
import { toErrorState } from "@/lib/api/query";
import { titleCase } from "@/lib/format";
import type { AnalyzeResult } from "@/lib/api/types";

/**
 * Submits network/security features to POST /api/detection/analyze.
 * The payload is passed through verbatim — no client-side inference happens.
 */
export function AnalyzeDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [sourceIp, setSourceIp] = useState("");
  const [destinationIp, setDestinationIp] = useState("");
  const [protocol, setProtocol] = useState("");
  const [sourcePort, setSourcePort] = useState("");
  const [destinationPort, setDestinationPort] = useState("");
  const [featuresJson, setFeaturesJson] = useState("{\n  \n}");
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalyzeResult | null>(null);

  const mutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) => detectionService.analyze(payload),
    onSuccess: (data) => setResult(data),
  });

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    setJsonError(null);
    let features: Record<string, unknown> = {};
    if (featuresJson.trim()) {
      try {
        const parsed = JSON.parse(featuresJson) as unknown;
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
          setJsonError("Features must be a JSON object.");
          return;
        }
        features = parsed as Record<string, unknown>;
      } catch {
        setJsonError("Features must be valid JSON.");
        return;
      }
    }

    const payload: Record<string, unknown> = { features };
    if (sourceIp) payload["source_ip"] = sourceIp;
    if (destinationIp) payload["destination_ip"] = destinationIp;
    if (protocol) payload["protocol"] = protocol;
    if (sourcePort) payload["source_port"] = Number(sourcePort);
    if (destinationPort) payload["destination_port"] = Number(destinationPort);

    mutation.mutate(payload);
  };

  const error = toErrorState(mutation.error);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ScanSearch className="text-primary size-4" aria-hidden /> Analyze network event
          </DialogTitle>
          <DialogDescription>
            Sends the feature payload to the detection service. Classification is performed entirely
            by the backend models.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="input">
          <TabsList>
            <TabsTrigger value="input">Input</TabsTrigger>
            <TabsTrigger value="result" disabled={!result}>
              Result
            </TabsTrigger>
          </TabsList>

          <TabsContent value="input">
            <form onSubmit={submit} className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="src-ip">source_ip</Label>
                  <Input id="src-ip" value={sourceIp} onChange={(e) => setSourceIp(e.target.value)} placeholder="10.0.0.12" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="dst-ip">destination_ip</Label>
                  <Input id="dst-ip" value={destinationIp} onChange={(e) => setDestinationIp(e.target.value)} placeholder="10.0.0.5" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="src-port">source_port</Label>
                  <Input id="src-port" type="number" value={sourcePort} onChange={(e) => setSourcePort(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="dst-port">destination_port</Label>
                  <Input id="dst-port" type="number" value={destinationPort} onChange={(e) => setDestinationPort(e.target.value)} />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="protocol">protocol</Label>
                  <Input id="protocol" value={protocol} onChange={(e) => setProtocol(e.target.value)} placeholder="tcp" />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="features">features (JSON object)</Label>
                <Textarea
                  id="features"
                  value={featuresJson}
                  onChange={(e) => setFeaturesJson(e.target.value)}
                  rows={8}
                  className="font-mono text-xs"
                  aria-invalid={Boolean(jsonError)}
                />
                <p className="text-muted-foreground text-xs">
                  Use the exact feature names expected by the backend detection schema.
                </p>
                {jsonError && <p className="text-destructive text-xs">{jsonError}</p>}
              </div>

              {error && <ErrorState title="Analysis failed" message={error.message} />}

              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={mutation.isPending}>
                  {mutation.isPending && <Loader2 className="size-4 animate-spin" aria-hidden />}
                  Run analysis
                </Button>
              </DialogFooter>
            </form>
          </TabsContent>

          <TabsContent value="result">
            {result && (
              <div className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="bg-secondary/40 rounded-lg border p-3">
                    <p className="text-muted-foreground text-[11px] tracking-wider uppercase">
                      Prediction
                    </p>
                    <p className="mt-1 text-base font-semibold">{titleCase(result.prediction)}</p>
                    <p className="text-muted-foreground text-xs">
                      Attack type: {titleCase(result.attack_type)}
                    </p>
                  </div>
                  <div className="bg-secondary/40 flex items-center justify-between rounded-lg border p-3">
                    <span className="text-muted-foreground text-[11px] tracking-wider uppercase">
                      Severity
                    </span>
                    <SeverityBadge severity={result.severity} />
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <ConfidenceMeter confidence={result.confidence} />
                  <RiskIndicator score={result.risk_score} />
                </div>

                {result.mitre?.technique_id && (
                  <div className="rounded-lg border p-3">
                    <p className="text-muted-foreground text-[11px] tracking-wider uppercase">
                      MITRE ATT&CK
                    </p>
                    <p className="mt-1 text-sm">
                      <span className="text-primary font-mono">{result.mitre.technique_id}</span>{" "}
                      {result.mitre.technique_name ?? ""}
                    </p>
                  </div>
                )}

                {result.explanation && (
                  <div className="rounded-lg border p-3">
                    <p className="text-muted-foreground text-[11px] tracking-wider uppercase">
                      Explanation
                    </p>
                    <p className="mt-1 text-sm">
                      {typeof result.explanation === "string"
                        ? result.explanation
                        : (result.explanation.summary ?? "—")}
                    </p>
                  </div>
                )}

                {result.recommended_action && (
                  <div className="border-primary/40 bg-primary/5 rounded-lg border p-3">
                    <p className="text-muted-foreground text-[11px] tracking-wider uppercase">
                      Recommended action
                    </p>
                    <p className="mt-1 text-sm">{result.recommended_action}</p>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
